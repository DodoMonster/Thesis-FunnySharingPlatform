<?php

/**
 * MsgGroupDO
 * @author auto create
 */
class MsgGroupDO
{
	
	/** 
	 * 123
	 **/
	public $appkey;
	
	/** 
	 * 123
	 **/
	public $description;
	
	/** 
	 * 123
	 **/
	public $gmt_create;
	
	/** 
	 * 123
	 **/
	public $gmt_modified;
	
	/** 
	 * 123
	 **/
	public $id;
	
	/** 
	 * 123
	 **/
	public $name;	
}
?>