<?php

/**
 * sku物流信息
 * @author auto create
 */
class SkusDeliveryTime
{
	
	/** 
	 * sku时间
	 **/
	public $skuDeliveryTime;
	
	/** 
	 * 商品skuId
	 **/
	public $skuId;	
}
?>