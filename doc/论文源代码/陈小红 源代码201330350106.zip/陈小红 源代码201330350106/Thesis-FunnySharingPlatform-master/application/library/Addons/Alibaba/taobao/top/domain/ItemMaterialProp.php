<?php

/**
 * 材质属性数据结构
 * @author auto create
 */
class ItemMaterialProp
{
	
	/** 
	 * 材质值列表
	 **/
	public $materials;	
}
?>