<?php

/**
 * 属性sku映射
 * @author auto create
 */
class PvMapSku
{
	
	/** 
	 * 用户选择的属性对
	 **/
	public $pv;
	
	/** 
	 * sku id
	 **/
	public $sku_id;	
}
?>