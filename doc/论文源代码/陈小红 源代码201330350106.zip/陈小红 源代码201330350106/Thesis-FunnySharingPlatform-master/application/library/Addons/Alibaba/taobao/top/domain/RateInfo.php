<?php

/**
 * 评价信息
 * @author auto create
 */
class RateInfo
{
	
	/** 
	 * 评价信息
	 **/
	public $rate_list;	
}
?>