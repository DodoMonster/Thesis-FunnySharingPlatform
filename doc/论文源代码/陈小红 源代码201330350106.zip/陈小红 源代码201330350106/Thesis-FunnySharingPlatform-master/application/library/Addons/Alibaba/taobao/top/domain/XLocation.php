<?php

/**
 * 位置信息
 * @author auto create
 */
class XLocation
{
	
	/** 
	 * 商品所在市
	 **/
	public $city;
	
	/** 
	 * 商品所在省
	 **/
	public $state;	
}
?>