<?php

/**
 * 卖家信息
 * @author auto create
 */
class SellerInfo
{
	
	/** 
	 * 卖家昵称
	 **/
	public $seller_nick;
	
	/** 
	 * 卖家类型
	 **/
	public $seller_type;
	
	/** 
	 * 卖家店铺名称
	 **/
	public $shop_name;	
}
?>