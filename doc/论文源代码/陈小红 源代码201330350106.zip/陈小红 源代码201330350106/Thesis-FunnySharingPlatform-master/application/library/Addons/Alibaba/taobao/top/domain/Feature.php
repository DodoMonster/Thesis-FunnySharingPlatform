<?php

/**
 * 类目属性
 * @author auto create
 */
class Feature
{
	
	/** 
	 * 属性键
	 **/
	public $attr_key;
	
	/** 
	 * 属性值
	 **/
	public $attr_value;	
}
?>