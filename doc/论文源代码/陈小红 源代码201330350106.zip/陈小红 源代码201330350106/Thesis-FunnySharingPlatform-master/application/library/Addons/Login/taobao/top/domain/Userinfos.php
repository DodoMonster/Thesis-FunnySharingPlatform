<?php

/**
 * 系统自动生成
 * @author auto create
 */
class Userinfos
{
	
	/** 
	 * email地址
	 **/
	public $email;
	
	/** 
	 * 头像url
	 **/
	public $iconUrl;
	
	/** 
	 * 手机号码
	 **/
	public $mobile;
	
	/** 
	 * 昵称
	 **/
	public $nick;
	
	/** 
	 * im密码
	 **/
	public $password;
	
	/** 
	 * 淘宝账号
	 **/
	public $taobaoid;
	
	/** 
	 * im用户名
	 **/
	public $userid;	
}
?>