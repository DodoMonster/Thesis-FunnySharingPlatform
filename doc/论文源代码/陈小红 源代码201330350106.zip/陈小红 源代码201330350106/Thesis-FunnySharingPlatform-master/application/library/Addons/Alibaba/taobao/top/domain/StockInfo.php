<?php

/**
 * 库存信息
 * @author auto create
 */
class StockInfo
{
	
	/** 
	 * 商品库存
	 **/
	public $item_quantity;
	
	/** 
	 * sku库存列表
	 **/
	public $sku_quantity_list;	
}
?>