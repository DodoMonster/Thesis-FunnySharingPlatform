<?php

/**
 * 价格信息
 * @author auto create
 */
class DetailPriceInfo
{
	
	/** 
	 * 商品对应的价格
	 **/
	public $item_price;
	
	/** 
	 * sku对应的价格列表
	 **/
	public $sku_price_list;	
}
?>