<?php

/**
 * 卖家发布的商品图文详情信息
 * @author auto create
 */
class DescInfo
{
	
	/** 
	 * 卖家发布的商品图文详情信息内容
	 **/
	public $content;
	
	/** 
	 * 卖家发布的商品图文详情来源平台
	 **/
	public $type;	
}
?>