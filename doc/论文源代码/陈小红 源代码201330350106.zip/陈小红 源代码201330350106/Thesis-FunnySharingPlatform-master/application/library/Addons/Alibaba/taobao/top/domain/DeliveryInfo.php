<?php

/**
 * 物流信息
 * @author auto create
 */
class DeliveryInfo
{
	
	/** 
	 * 运费信息
	 **/
	public $carriage_list;
	
	/** 
	 * 物流目的地
	 **/
	public $destination;
	
	/** 
	 * 所在地
	 **/
	public $location;	
}
?>