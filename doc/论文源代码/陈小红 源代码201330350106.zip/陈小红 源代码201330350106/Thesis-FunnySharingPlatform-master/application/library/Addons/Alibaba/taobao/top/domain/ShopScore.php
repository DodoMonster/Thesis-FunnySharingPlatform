<?php

/**
 * 店铺动态评分信息
 * @author auto create
 */
class ShopScore
{
	
	/** 
	 * 发货速度评分
	 **/
	public $delivery_score;
	
	/** 
	 * 商品描述评分
	 **/
	public $item_score;
	
	/** 
	 * 服务态度评分
	 **/
	public $service_score;	
}
?>