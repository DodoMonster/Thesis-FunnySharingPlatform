<?php

/**
 * 价格单元
 * @author auto create
 */
class PriceUnit
{
	
	/** 
	 * 价格Label
	 **/
	public $name;
	
	/** 
	 * 售卖价格,单位元
	 **/
	public $price;
	
	/** 
	 * price后面的tips
	 **/
	public $tips;	
}
?>