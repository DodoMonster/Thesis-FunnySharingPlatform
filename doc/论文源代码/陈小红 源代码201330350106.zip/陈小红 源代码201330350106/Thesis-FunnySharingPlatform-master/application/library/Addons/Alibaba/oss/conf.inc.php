<?php
define('OSS_ACCESS_ID', 'Ed70Yhymna1UlABC');
define('OSS_ACCESS_KEY', 'gzohp60M6wzCC49Uu21gBP42Xpkv1x');
define('OSS_ENDPOINT', 'oss-cn-shenzhen.aliyuncs.com');
define('OSS_TEST_BUCKET', 'menda');

//define('OSS_ACCESS_ID', 'sjonobkzs5kpdDNs');
//define('OSS_ACCESS_KEY', 'mchyi3ewZzTudf3xUkkGW95f0qE3CF');
//define('OSS_ENDPOINT', 'oss-cn-shenzhen.aliyuncs.com');
//define('OSS_TEST_BUCKET', 'shenmafuli1');

//是否记录日志
define('ALI_LOG', FALSE);

//自定义日志路径，如果没有设置，则使用系统默认路径，在./logs/
//define('ALI_LOG_PATH','');

//是否显示LOG输出
define('ALI_DISPLAY_LOG', FALSE);

//语言版本设置
define('ALI_LANG', 'zh');
