<?php

/**
 * 商品购买约束
 * @author auto create
 */
class ItemBuyInfo
{
	
	/** 
	 * 是否支持购物车
	 **/
	public $cart_support;	
}
?>