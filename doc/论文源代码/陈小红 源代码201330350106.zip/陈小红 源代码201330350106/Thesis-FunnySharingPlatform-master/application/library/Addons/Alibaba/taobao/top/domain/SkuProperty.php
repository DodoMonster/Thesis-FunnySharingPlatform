<?php

/**
 * SKU属性
 * @author auto create
 */
class SkuProperty
{
	
	/** 
	 * sku属性id
	 **/
	public $prop_id;
	
	/** 
	 * sku属性名称
	 **/
	public $prop_name;
	
	/** 
	 * SKU属性值
	 **/
	public $values;	
}
?>