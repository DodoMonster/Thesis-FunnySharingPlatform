<?php

/**
 * sku物流信息
 * @author auto create
 */
class SkusDeliveryTime
{
	
	/** 
	 * sku时间
	 **/
	public $sku_delivery_time;
	
	/** 
	 * 商品skuId
	 **/
	public $sku_id;	
}
?>