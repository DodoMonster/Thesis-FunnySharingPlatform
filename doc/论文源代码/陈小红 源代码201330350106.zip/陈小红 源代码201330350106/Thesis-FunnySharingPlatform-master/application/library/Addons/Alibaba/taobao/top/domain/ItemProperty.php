<?php

/**
 * 商品属性
 * @author auto create
 */
class ItemProperty
{
	
	/** 
	 * 商品属性名
	 **/
	public $name;
	
	/** 
	 * 商值属性值
	 **/
	public $value;	
}
?>