<?php

/**
 * com.taobao.xselect.domain.SkuSelectInfo
 * @author auto create
 */
class SkuSelectInfo
{
	
	/** 
	 * 外部ID
	 **/
	public $outer_id;
	
	/** 
	 * sku id
	 **/
	public $sku_id;	
}
?>