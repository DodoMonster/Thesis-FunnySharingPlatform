<?php

/**
 * 运费信息
 * @author auto create
 */
class Carriage
{
	
	/** 
	 * 运费
	 **/
	public $name;
	
	/** 
	 * 快递公司
	 **/
	public $price;	
}
?>