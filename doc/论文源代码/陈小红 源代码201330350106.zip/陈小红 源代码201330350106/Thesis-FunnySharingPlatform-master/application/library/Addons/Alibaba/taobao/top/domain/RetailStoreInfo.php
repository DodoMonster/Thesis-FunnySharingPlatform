<?php

/**
 * 线下门店信息
 * @author auto create
 */
class RetailStoreInfo
{
	
	/** 
	 * 商品可售线下门店
	 **/
	public $store_list;	
}
?>