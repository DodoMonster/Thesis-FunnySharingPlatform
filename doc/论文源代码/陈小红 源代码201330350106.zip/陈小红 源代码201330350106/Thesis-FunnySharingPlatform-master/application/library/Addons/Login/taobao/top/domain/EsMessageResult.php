<?php

/**
 * 应用消息查询结果
 * @author auto create
 */
class EsMessageResult
{
	
	/** 
	 * 消息序列
	 **/
	public $messages;
	
	/** 
	 * nextkey
	 **/
	public $nextKey;	
}
?>