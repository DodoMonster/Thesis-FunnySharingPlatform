<?php

/**
 * 发送结果
 * @author auto create
 */
class SendMessageResult
{
	
	/** 
	 * 发送的唯一号
	 **/
	public $task_id;	
}
?>