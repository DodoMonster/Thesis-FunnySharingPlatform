<?php

/**
 * sku库存
 * @author auto create
 */
class SkuQuantity
{
	
	/** 
	 * 库存数
	 **/
	public $quantity;
	
	/** 
	 * sku id
	 **/
	public $sku_id;	
}
?>